দৈনিক বাজার হিসাব — Android প্রজেক্ট

এই সংস্করণে OTP বা মোবাইল নম্বর লাগবে না। ব্যবহারকারী নিজে একটি গোপন কোড তৈরি করবেন।
অন্য ফোনে একই কোড দিয়ে প্রবেশ করলে একই অনলাইন হিসাব দেখা যাবে।

গুরুত্বপূর্ণ:
- গোপন কোড কমপক্ষে ১০ অক্ষর/সংখ্যার হতে হবে।
- কোডটি হারালে অ্যাকাউন্ট/হিসাব উদ্ধার করার কোনো বিকল্প থাকবে না।
- কোডটি অন্য কাউকে দেবেন না। সহজ কোড যেমন 1234567890 ব্যবহার করবেন না।
- এটি Firebase Authentication-এর Email/Password সুবিধা ব্যবহার করে; অ্যাপ নিজে আপনার আসল ইমেইল বা ফোন নম্বর চায় না।
- Firebase প্রকল্প ও ইন্টারনেট সংযোগ প্রয়োজন। Firebase-এর বিনামূল্যের সীমা/নীতিমালা পরিবর্তিত হতে পারে।

Firebase সেটআপ:
১. https://console.firebase.google.com এ গিয়ে একটি Firebase Project তৈরি করুন।
২. Project Overview থেকে Android অ্যাপ যোগ করুন।
৩. Package name হুবহু দিন: com.dailybazar.app
৪. google-services.json ডাউনলোড করে প্রজেক্টের app/ ফোল্ডারে রাখুন।
৫. Firebase Console > Authentication > Sign-in method এ Email/Password চালু করুন।
৬. Firebase Console > Firestore Database থেকে database তৈরি করুন।
৭. Firestore Rules অংশে এই প্রজেক্টের firestore.rules ফাইলের নিয়ম প্রকাশ করুন।
৮. Android Studio-তে প্রজেক্ট খুলে Gradle Sync করুন।

APK তৈরি:
১. Android Studio-তে এই ফোল্ডারটি খুলুন।
২. app/google-services.json ফাইলটি আছে নিশ্চিত করুন।
৩. উপরের Sync Now চাপুন (যদি দেখায়)।
৪. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
৫. Build শেষ হলে notification-এর Locate চাপলে APK ফাইল পাবেন।

এই ZIP হলো Android Studio source project; তৈরি APK নয়। Firebase config ছাড়া অ্যাপ অনলাইনে কাজ করবে না।
