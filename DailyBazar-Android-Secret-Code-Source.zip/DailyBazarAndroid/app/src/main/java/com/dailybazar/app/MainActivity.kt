package com.dailybazar.app

import android.os.Bundle
import android.content.ContentValues
import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.security.MessageDigest
import java.util.Date
import java.util.Locale

data class MarketItem(val name: String = "", val quantity: String = "", val price: String = "") {
    val total: Double get() = (quantity.toDoubleOrNull() ?: 0.0) * (price.toDoubleOrNull() ?: 0.0)
}
data class SavedMarket(val id: String, val date: String, val buyer: String, val total: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme { DailyBazarApp() } }
    }
}

@Composable
fun DailyBazarApp() {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var secretCode by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("নতুন হলে নতুন গোপন কোড তৈরি করুন। আগে কোড থাকলে সেটি দিয়ে প্রবেশ করুন।") }

    fun accountEmail(code: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(code.trim().toByteArray(Charsets.UTF_8))
        val hash = digest.joinToString("") { "%02x".format(it) }
        return "$hash@dailybazar.app"
    }

    if (user == null) {
        Column(
            Modifier.fillMaxSize().padding(22.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "দৈনিক বাজার হিসাব",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text("একটি গোপন কোড দিয়ে তোমার হিসাব যেকোনো ফোনে ব্যবহার করো।")
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = secretCode,
                onValueChange = { secretCode = it },
                label = { Text("তোমার গোপন কোড") },
                supportingText = { Text("কমপক্ষে ১০ অক্ষর/সংখ্যা ব্যবহার করো") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val code = secretCode.trim()
                    if (code.length < 10) {
                        message = "নিরাপত্তার জন্য কমপক্ষে ১০ অক্ষরের গোপন কোড দাও"
                        return@Button
                    }
                    busy = true
                    auth.createUserWithEmailAndPassword(accountEmail(code), code)
                        .addOnCompleteListener { task ->
                            busy = false
                            if (task.isSuccessful) {
                                user = auth.currentUser
                                message = "নতুন হিসাব তৈরি হয়েছে"
                            } else {
                                val error = task.exception?.message.orEmpty()
                                message = if (error.contains("already", ignoreCase = true) ||
                                    error.contains("in use", ignoreCase = true)) {
                                    "এই কোড আগে থেকেই আছে। আগের কোড দিয়ে প্রবেশ করো।"
                                } else {
                                    "নতুন কোড তৈরি হয়নি: ${task.exception?.localizedMessage ?: "আবার চেষ্টা করো"}"
                                }
                            }
                        }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "অপেক্ষা করুন..." else "নতুন গোপন কোড তৈরি") }

            OutlinedButton(
                onClick = {
                    val code = secretCode.trim()
                    if (code.length < 10) {
                        message = "তোমার আগের গোপন কোডটি লিখো (কমপক্ষে ১০ অক্ষর)"
                        return@OutlinedButton
                    }
                    busy = true
                    auth.signInWithEmailAndPassword(accountEmail(code), code)
                        .addOnCompleteListener { task ->
                            busy = false
                            if (task.isSuccessful) {
                                user = auth.currentUser
                                message = "লগইন সফল"
                            } else {
                                message = "কোড মেলেনি। কোড ঠিক আছে কি না দেখো।"
                            }
                        }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text("আগের গোপন কোড দিয়ে প্রবেশ") }

            Spacer(Modifier.height(12.dp))
            Text(message, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(
                "সতর্কতা: কোডটি হারালে হিসাব ফেরত পাওয়া যাবে না। কোডটি অন্য কাউকে দিও না এবং নিরাপদে লিখে রাখো।",
                style = MaterialTheme.typography.bodySmall
            )
        }
    } else {
        MarketHome(
            uid = user!!.uid,
            phone = "গোপন কোড দিয়ে সংযুক্ত",
            onLogout = { auth.signOut(); user = null; secretCode = "" },
            db = db,
            context = context
        )
    }
}

@Composable
fun MarketHome(uid: String, phone: String, onLogout: () -> Unit, db: FirebaseFirestore, context: Context) {
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    var date by remember { mutableStateOf(today) }
    var buyer by remember { mutableStateOf("") }
    var rows by remember { mutableStateOf(List(5) { MarketItem() }) }
    var status by remember { mutableStateOf("") }
    var history by remember { mutableStateOf<List<SavedMarket>>(emptyList()) }
    val total = rows.sumOf { it.total }

    fun loadHistory() {
        db.collection("users").document(uid).collection("markets").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(30)
            .get().addOnSuccessListener { snap ->
                history = snap.documents.map { d ->
                    SavedMarket(d.id, d.getString("date") ?: "", d.getString("buyer") ?: "", d.getDouble("total") ?: 0.0)
                }
            }.addOnFailureListener { status = "পুরোনো হিসাব আনা যায়নি: ${it.localizedMessage}" }
    }
    LaunchedEffect(uid) { loadHistory() }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("দৈনিক বাজার হিসাব", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            TextButton(onClick = onLogout) { Text("লগআউট") }
        }
        Text(phone, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(date, { date = it }, label = { Text("তারিখ (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(buyer, { buyer = it }, label = { Text("নাম / বাজারের বিবরণ (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("পণ্যের তালিকা", fontWeight = FontWeight.Bold)
            TextButton(onClick = { rows = rows + MarketItem() }) { Text("+ পণ্য যোগ") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(rows) { index, item ->
                Card(shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("পণ্য ${index + 1}", fontWeight = FontWeight.SemiBold)
                            TextButton(onClick = { rows = rows.filterIndexed { i, _ -> i != index } }) { Text("মুছুন") }
                        }
                        OutlinedTextField(item.name, { v -> rows = rows.toMutableList().also { it[index] = item.copy(name = v) } }, label = { Text("পণ্যের নাম") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(item.quantity, { v -> rows = rows.toMutableList().also { it[index] = item.copy(quantity = v) } }, label = { Text("পরিমাণ") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                            OutlinedTextField(item.price, { v -> rows = rows.toMutableList().also { it[index] = item.copy(price = v) } }, label = { Text("দাম") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                        }
                        Text("মোট: ৳ ${"%.2f".format(item.total)}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Text("সর্বমোট বাজার খরচ: ৳ ${"%.2f".format(total)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val valid = rows.filter { it.price.isNotBlank() && it.name.isNotBlank() }
                val payload = hashMapOf(
                    "date" to date, "buyer" to buyer, "total" to valid.sumOf { it.total },
                    "items" to valid.map { mapOf("name" to it.name, "quantity" to it.quantity, "price" to it.price, "total" to it.total) },
                    "createdAt" to System.currentTimeMillis()
                )
                db.collection("users").document(uid).collection("markets").add(payload)
                    .addOnSuccessListener { status = "হিসাব অনলাইনে সংরক্ষণ হয়েছে"; loadHistory() }
                    .addOnFailureListener { status = "সংরক্ষণ হয়নি: ${it.localizedMessage}" }
            }, modifier = Modifier.weight(1f)) { Text("অনলাইনে সেভ") }
            OutlinedButton(onClick = { exportPdf(context, date, buyer, rows) }, modifier = Modifier.weight(1f)) { Text("PDF তৈরি") }
        }
        Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        Text("আগের হিসাব", fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.heightIn(max = 115.dp)) {
            itemsIndexed(history) { _, h -> Text("${h.date}  •  ${h.buyer}  •  ৳ ${"%.2f".format(h.total)}", modifier = Modifier.padding(vertical = 3.dp)) }
        }
    }
}

fun exportPdf(context: Context, date: String, buyer: String, rows: List<MarketItem>) {
    val valid = rows.filter { it.price.isNotBlank() && it.name.isNotBlank() }
    if (valid.isEmpty()) { Toast.makeText(context, "দাম লেখা কোনো পণ্য নেই", Toast.LENGTH_SHORT).show(); return }
    val doc = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = doc.startPage(pageInfo)
    val canvas = page.canvas
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 17f }
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    canvas.drawText("দৈনিক বাজারের হিসাব", 40f, 48f, paint)
    paint.typeface = Typeface.DEFAULT
    paint.textSize = 13f
    canvas.drawText("তারিখ: $date    ${buyer}", 40f, 76f, paint)
    val left = 35f; val widths = floatArrayOf(220f, 95f, 105f, 105f)
    val headers = listOf("পণ্যের নাম", "পরিমাণ", "দাম", "মোট দাম")
    var y = 105f
    fun cell(x: Float, top: Float, w: Float, h: Float, text: String, bold: Boolean = false) {
        canvas.drawRect(x, top, x+w, top+h, Paint().apply { style = Paint.Style.STROKE; strokeWidth = 1.2f; color = android.graphics.Color.BLACK })
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 14f; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }
        canvas.drawText(text.take(25), x+6, top+22, p)
    }
    var x = left
    headers.forEachIndexed { i, h -> cell(x, y, widths[i], 32f, h, true); x += widths[i] }
    y += 32f
    valid.forEach { item ->
        x = left
        val vals = listOf(item.name, item.quantity, item.price, "%.2f".format(item.total))
        vals.forEachIndexed { i, v -> cell(x, y, widths[i], 34f, v); x += widths[i] }
        y += 34f
    }
    paint.typeface = Typeface.DEFAULT_BOLD; paint.textSize = 17f
    canvas.drawText("সর্বমোট: ৳ %.2f".format(valid.sumOf { it.total }), 40f, y+35f, paint)
    doc.finishPage(page)
    val name = "DailyBazar_${date}.pdf"
    try {
        val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, "application/pdf") }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri != null) context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
        Toast.makeText(context, "PDF Downloads ফোল্ডারে সেভ হয়েছে", Toast.LENGTH_LONG).show()
    } catch (e: Exception) { Toast.makeText(context, "PDF তৈরি হয়নি: ${e.localizedMessage}", Toast.LENGTH_LONG).show() }
    finally { doc.close() }
}
